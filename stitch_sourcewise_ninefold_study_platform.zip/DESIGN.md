---
name: SourceWise
colors:
  surface: '#fbf8ff'
  surface-dim: '#d7d8f4'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#edecff'
  surface-container-high: '#e6e6ff'
  surface-container-highest: '#e0e0fc'
  on-surface: '#181a2e'
  on-surface-variant: '#55423e'
  inverse-surface: '#2d2f44'
  inverse-on-surface: '#f1efff'
  outline: '#88726d'
  outline-variant: '#dbc1ba'
  surface-tint: '#9a442d'
  primary: '#9a442d'
  on-primary: '#ffffff'
  primary-container: '#e07a5f'
  on-primary-container: '#5b1604'
  inverse-primary: '#ffb4a1'
  secondary: '#9c4141'
  on-secondary: '#ffffff'
  secondary-container: '#fe8e8b'
  on-secondary-container: '#762527'
  tertiary: '#57615c'
  on-tertiary: '#ffffff'
  tertiary-container: '#8f9994'
  on-tertiary-container: '#28312d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd2'
  primary-fixed-dim: '#ffb4a1'
  on-primary-fixed: '#3c0800'
  on-primary-fixed-variant: '#7c2e19'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#7d2a2c'
  tertiary-fixed: '#dbe5df'
  tertiary-fixed-dim: '#bfc9c3'
  on-tertiary-fixed: '#151d1a'
  on-tertiary-fixed-variant: '#3f4945'
  background: '#fbf8ff'
  on-background: '#181a2e'
  surface-variant: '#e0e0fc'
typography:
  display-hero:
    fontFamily: Epilogue
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 68px
    letterSpacing: -0.025em
  display-hero-mobile:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Epilogue
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Epilogue
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  space-4xl: 6rem
  gutter-mobile: 1rem
  gutter-desktop: 2rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3.5rem
---

## Brand & Style

This design system blends academic rigor with mythical warmth, drawing inspiration from the nine-tailed fox (kitsune)—a creature symbolizing wisdom, adaptability, and curated insight. Designed for high-achieving scholars, students, and curious lifelong learners, the aesthetic elevates educational technology from sterile utility into an inviting, tactile sanctuary of knowledge.

The design movement combines **warm organic minimalism** with **delicate frosted glassmorphism** and subtle **low-poly faceted motifs**. Interfaces prioritize generous breathing room, layered translucent ivory card structures, and soft, comforting hues over harsh institutional blues and stark whites. Visual anchors mimic folded parchment and geometric crystal reflections without cluttering readability. The emotional tone is reassuring, focused, and scholarly—instilling confidence and reducing study fatigue through warm, harmonious visual discipline.

## Colors

The palette establishes an organic, luminous foundation calibrated for prolonged screen time and high cognitive clarity.

- **Primary Canvas & Neutral Surfaces:**
  - `Canvas Base`: `#FAFAF7` (Warm Ivory) – primary background reducing optical glare.
  - `Surface Subdued`: `#F5F3EF` (Cream Alpaca) – container fills, section divides, and nested panels.
  - `Surface Elevated / Glass`: `rgba(255, 255, 255, 0.72)` – frosted interactive card planes.
- **Accents & Energetic Hues:**
  - `Primary (Terracotta Fox)`: `#E07A5F` – primary actions, high-emphasis states, and authoritative milestones.
  - `Secondary (Soft Coral)`: `#F28482` – active tabs, focus rings, callout badges, and progress nodes.
  - `Peach Bloom`: `#FFE8D6` – highlight containers, selected row backgrounds, and soft notifications.
  - `Dusty Rose`: `#DDBEA9` – secondary metadata tags, borders, and tactile slider tracks.
- **Support & Functional Harmony:**
  - `Sage Green`: `#D8E2DC` – verified credentials, reading completion states, and success indicators.
  - `Celestial Lavender`: `#E5E0F2` – citations, contextual cross-references, and conceptual tags.
- **Typography & Structural Inks:**
  - `Ink Primary`: `#2B2D42` (Deep Charcoal Slate) – maximum contrast for headlines and primary body text.
  - `Ink Secondary`: `#4A4E69` (Muted Charcoal Plum) – secondary descriptions, metadata, and placeholder copy.
  - `Ink Disabled`: `rgba(74, 78, 105, 0.45)` – inactive controls and muted separators.

## Typography

The pairing reconciles structured geometric refinement with modern humanistic legibility:

- **Headings (Epilogue):** Chosen for its sculpted geometric proportion, sharp apexes, and editorial cadence. It evokes precision and scholarly warmth while hinting at low-poly crystalline facets. Heading sizes `32px` and above must automatically cascade down on mobile viewports to prevent line-wrapping truncation.
- **Body & Controls (Plus Jakarta Sans):** Its rounded, open letterforms balance warmth with high-density legibility. Generous line heights are enforced across long-form research papers and reading dashboards to avoid reading fatigue.

## Layout & Spacing

This design system uses a strict 8-point base scale with a 4-point micro-scale for compact controls and nested badges.

- **Grid Structure:**
  - **Desktop (≥1200px):** 12-column responsive fluid grid, `1320px` maximum content container width, `2rem` (32px) gutters, and `3.5rem` (56px) outer margins.
  - **Tablet (768px – 1199px):** 8-column grid with `1.5rem` (24px) gutters and `2rem` (32px) outer margins.
  - **Mobile (<768px):** 4-column single-stack grid with `1rem` (16px) gutters and `1rem` (16px) outer margins.
- **Rhythm & Whitespace:** Section spacing embraces educational focus with expansive margins (`space-3xl` to `space-4xl`). Content blocks within cards and study panels rely on `space-md` to `space-xl` padding, keeping study material isolated and digestible.

## Elevation & Depth

Depth is treated as ethereal and ambient rather than heavily physical, using diffuse, warm-tinted dropshadows paired with frosted glass.

- **Low-Poly Dimensionality:** Background accent vectors utilize subtle geometric polygons in semi-transparent layers (`rgba(224, 122, 95, 0.06)` and `rgba(242, 132, 130, 0.08)`), imparting faceted depth without distracting from text.
- **Glassmorphism Layers:**
  - `Glass Baseline`: Background blur `16px`, surface fill `rgba(250, 250, 247, 0.78)`, border `1px solid rgba(221, 190, 169, 0.35)`.
  - `Glass Interactive Hover`: Background blur `20px`, surface fill `rgba(255, 255, 255, 0.90)`, border `1px solid rgba(224, 122, 95, 0.4)`.
- **Shadow System:**
  - `Elevation 1 (Resting Cards)`: `0 4px 20px -2px rgba(43, 45, 66, 0.04), 0 2px 6px -1px rgba(224, 122, 95, 0.03)`
  - `Elevation 2 (Floating Popovers & Flyouts)`: `0 12px 32px -4px rgba(43, 45, 66, 0.08), 0 4px 12px -2px rgba(224, 122, 95, 0.06)`
  - `Elevation 3 (Modals & Overlays)`: `0 24px 48px -8px rgba(43, 45, 66, 0.12), 0 8px 24px -4px rgba(74, 78, 105, 0.08)`

## Shapes

The design system embraces an elongated, fluid pill aesthetic (`roundedness: 3`) contrasted against geometric 45° and 60° low-poly accents in decorative zones. 

- **Primary Interactive Elements:** Buttons, chips, status pills, and search inputs adopt full pill geometry (`border-radius: 9999px`).
- **Surface Enclosures:** Content cards, study matrices, and dialogs utilize deep radii (`2rem` / `32px` on desktop, `1.25rem` / `20px` on mobile).
- **Geometric Contrast:** Feature cards may feature clipped low-poly geometric accent corners or decorative polygon masks in SVG iconography to express the kitsune tail faceted geometry.

## Components

### Buttons
- **Primary:** Full pill (`border-radius: 9999px`), Terracotta background (`#E07A5F`), white text (`#FFFFFF`), subtle coral ambient shadow (`0 8px 20px -4px rgba(224, 122, 95, 0.4)`). Hover shifts background to Coral (`#F28482`) with a slight upward translation (`translateY(-1px)`).
- **Secondary / Ghost:** Ivory glass fill (`rgba(255, 255, 255, 0.6)`), border `1.5px solid #DDBEA9`, text `#2B2D42`. Hover changes fill to `#FFE8D6` with border `#E07A5F`.
- **Sizes:** Large (`48px` height, `24px` horizontal padding), Medium (`40px` height, `20px` horizontal padding), Compact (`32px` height, `14px` horizontal padding).

### Chips & Badges
- **Status & Subject Chips:** Pill shape with `8px` vertical and `14px` horizontal padding. Lavender (`#E5E0F2`) with `#4A4E69` text for taxonomy; Sage Green (`#D8E2DC`) with `#2B2D42` text for mastery/verified badges; Peach (`#FFE8D6`) with `#E07A5F` text for active learning tracks.

### Text Inputs & Search Fields
- **Container:** Rounded pill or high-radius container (`20px`), background `#FFFFFF`, border `1.5px solid rgba(221, 190, 169, 0.5)`. Text `#2B2D42`, placeholder text `#4A4E69` at `60%` opacity.
- **Focus State:** Border expands slightly to `#E07A5F` with an ambient glow (`0 0 0 4px rgba(242, 132, 130, 0.18)`). Includes low-poly faceted clear/search action icons.

### Checkboxes & Radio Buttons
- **Checkboxes:** Rounded square (`border-radius: 6px`), `#F5F3EF` base with `#DDBEA9` border. Selected state triggers an `#E07A5F` fill with a crisp `#FFFFFF` geometric checkmark.
- **Radio Buttons:** Full circle, outer ring `#DDBEA9`. Active state nests an `#E07A5F` central dot surrounded by `#FAFAF7` buffer space.

### Cards
- **Study & Source Cards:** Frosted cream surface (`rgba(255, 255, 255, 0.75)` with `16px` backdrop blur), `1px solid rgba(221, 190, 169, 0.4)`, `24px` internal padding, rounded to `24px`. Resting ambient shadow elevation 1, lifting to elevation 2 with a low-poly peach facet highlight on hover.

### Fox-Tail Progress Tracker
- **Custom Learning Element:** Segmented progress bar modeled after the nine low-poly fox tails. Unfilled segments sit in muted `#F5F3EF` with `#DDBEA9` thin strokes; completed milestones illuminate sequentially from `#FFE8D6` through `#F28482` to vibrant `#E07A5F`.